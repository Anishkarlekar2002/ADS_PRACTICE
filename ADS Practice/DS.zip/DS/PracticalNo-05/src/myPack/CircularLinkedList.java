package myPack;

import org.w3c.dom.Node;

public class CircularLinkedList {
    Node head; 
	    Node tail; 

	    // Node class  	   
	    static class Node {  	   
	    	int data;  	        
	    	Node next; 

     Node(int data) {  
    	 this.data = data; 
    	 this.next = null; 
	        }  	  
     } 

	    
// Create a circular list with a single node 
public void create(int data) {   
	Node newNode = new Node(data);   
	if (head == null) { 
	            head = newNode;  	   
	            tail = newNode; 
	            tail.next = head;  // Circular link 
     } else {    
    	 tail.next = newNode;    
    	 tail = newNode; 
	            tail.next = head;  
	            // Circular link 
	        } 
	    } 

	    // Display the circular list  	  
public void display() {  	       
	if (head == null) { 
	            System.out.println("List is empty"); 
	            return; 
	        } 
     Node temp = head;         
     do { 
	            System.out.print(temp.data + " ");  	
	            temp = temp.next;  	      
	            }
     while (temp != head); 
	        System.out.println(); 
	    } 

 // Insert at the end   
public void insert(int data) {     
	create(data); 
	    } 

	    // Delete a node by value  	 
public void delete(int value) {  	     
	if (head == null) { 
	            System.out.println("List is empty"); 
	            return;  	        } 
	        if (head.data == value && head.next == head) {  	  
	        	head = null;  	         
	        	tail = null; 
	            return; 
	        } 
	        Node temp = head; 
	        while (temp.next != head && temp.next.data != value) {  	  
	        	temp = temp.next; 
    } 
    if (temp.next == head) { 
        System.out.println("Value not found"); 
     } else {  
    	 temp.next = temp.next.next;   
    	 if (temp.next == head) {               
    		 tail = temp; 
	            } 
	        } 
	    } 

 public static void main(String[] args) {     
	 CircularLinkedList list = new CircularLinkedList(); 
	        System.out.println("List is:");  	      
	        list.create(50);  	       
	        list.create(25);  	     
	        list.create(30);  	      
	        list.display();   
	         
	        System.out.println("After inserting node:");  
	        list.insert(40); 
	        list.display();  
	         
	        System.out.println("After deleting node:");  
	        list.delete(25);  	   
	        list.display();   
	    } 


}

package myPack;

import org.w3c.dom.Node;

public class SinglyLinkedList {
    Node head; 
    
	    // Node class  
    static class Node {  	     
    	int data;  	      
    	Node next; 

     Node(int data) {             
    	 this.data = data;             
    	 this.next = null; 
	        } 
	    } 

 // Create new node   
    public void create(int data) {  
    	Node newNode = new Node(data); 
	        if (head == null) {  	  
	        	head = newNode;  	     
	        	} else { 
	            Node temp = head;  	   
	            while (temp.next != null) {  	
	            	temp = temp.next; 
	            } 
	            temp.next = newNode; 
	        } 
	    } 
// Display the list   
    public void display() { 
	        if (head == null) { 
	            System.out.println("List is empty"); 
	            return; 
	        } 
	        Node temp = head;  	       
	        while (temp != null) { 
	            System.out.print(temp.data + " ");  
	            temp = temp.next; 
	        } 
	        System.out.println(); 
	    } 

 // Insert at the end      
    public void insert(int data) {
    	create(data); 
	    } 

	    // Delete a node by value 
	    public 	void	 delete(int value) { 
	        if (head == null) { 
	            System.out.println("List is empty"); 
	            return;  	        } 
	        if (head.data == value) {  	
	        	head = head.next;  	    
	        	return; 
	        } 
	        Node temp = head; 
	        while (temp.next != null && temp.next.data != value) {  	 
	        	temp = temp.next; 
	        } 
	        if (temp.next == null) { 
	            System.out.println("Value not found"); 
	        } else { 
	            temp.next = temp.next.next; 
	        } 
	    	} 

 public static void main(String[] args) { 
	 SinglyLinkedList list = new SinglyLinkedList(); 
	        System.out.println("List is:");  	   
	        list.create(10);  	  
	        list.create(20); 
	        list.create(30);      
	        list.display();   
	        System.out.println("After inserting node:");  	
	        list.insert(40); 
	        list.display();   

	        System.out.println("After deleting node:");  	
	        list.delete(20);  	        list.display();   
	    } 


}

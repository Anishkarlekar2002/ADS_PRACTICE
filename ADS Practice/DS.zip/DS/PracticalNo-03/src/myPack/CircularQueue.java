package myPack;

import java.util.Scanner;

public class CircularQueue {
	// Maximum size of the circular queue   
	private int maxSize; 
    // Array to store the circular queue elements    
	private int[] queueArray; 
    // Index of the front element 
    private int front;     // Index of the rear element 
    private int rear; 
    // Constructor to initialize the circular queue with a given size     
    public CircularQueue(int size) {       
    	maxSize = size; 
        queueArray = new int[maxSize]; 
        front = -1;  // Initially set front and rear to -1 to indicate an empty queue      
        rear = -1; 
    } 
    // Method to enqueue (add) an item to the circular queue  
    public void enqueue(int item) {       
    	if ((rear + 1) % maxSize == front) { 
            System.out.println("Queue is full. Cannot enqueue."); 
        } else {
        	if (isEmpty()) {     
        		front = 0; 
            } 
            rear = (rear + 1) % maxSize;   
            queueArray[rear] = item; 
            System.out.println(item + " enqueued to the queue."); 
        } 
    } 
    // Method to dequeue (remove) an item from the circular queue  
    public int dequeue() {         
    	if (isEmpty()) { 
            System.out.println("Queue is empty. Cannot dequeue."); 
            return -1;  // Assuming -1 represents an empty value 
        } else { 
            int item = queueArray[front];  
            if (front == rear) { 
                // Reset front and rear to -1 to indicate an empty queue     
            	front = -1;           
            	rear = -1;          
            	} else { 
                front = (front + 1) % maxSize; 
            }             return item; 
        } 
    } 
    // Method to peek at the front element of the circular queue without removing it    
    public int peek() {       
    	if (isEmpty()) { 
            System.out.println("Queue is empty. No peek value.");
            return -1;  // Assuming -1 represents an empty value 
        } else { 
            return queueArray[front]; 
        } 
    } 
    // Method to check if the circular queue is empty   
    public boolean isEmpty() {       
    	return front == -1 && rear == -1; 
    } 
    // Method to display the elements in the queue 
    public void display() {  
    	if (isEmpty()) { 
            System.out.println("Queue is empty."); 
        } else {         
        	int i = front; 
            System.out.print("Queue elements: ");
            while (i != rear) { 
                System.out.print(queueArray[i] + " ");        
                i = (i + 1) % maxSize; 
            } 
            System.out.println(queueArray[rear]);  // Print the last element 
        } 
    } 
    public static void main(String[] args) { 
        Scanner scanner = new Scanner(System.in); 
        CircularQueue queue = new CircularQueue(5);  
        // Create a circular queue with a size of 5       
        int choice, value; 
        // Display menu to the user     
        while (true) { 
            System.out.println("\nCircular Queue Operations Menu:"); 
            System.out.println("1. Enqueue"); 
            System.out.println("2. Dequeue"); 
            System.out.println("3. Peek"); 
            System.out.println("4. Display Queue"); 
            System.out.println("5. Exit"); 
            System.out.print("Enter your choice: ");            
            choice = scanner.nextInt(); 
            switch (choice) {                 
            case 1: // Enqueue operation 
                    System.out.print("Enter value to enqueue: ");      
                    value = scanner.nextInt();                 
                    queue.enqueue(value);                    
                    break; 
                case 2: // Dequeue operation 
                    System.out.println("Dequeued: " + queue.dequeue()); 
                    break; 
                    case 3: // Peek operation 
                    System.out.println("Front element is: " + queue.peek()); 
                    break; 
                case 4: // Display all elements in queue        
                	queue.display();                 
                	break;                
                	case 5: // Exit program 
                    System.out.println("Exiting...");      
                    scanner.close();                  
                    return;      
                    default: // Invalid choice 
                    System.out.println("Invalid choice. Please try again."); 
            } 
        } 
    } 


}

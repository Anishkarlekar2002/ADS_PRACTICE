package myPack;

import java.util.Scanner;

public class BubbleSort {
	   public static void main(String[] args) {      
		   Scanner scanner = new Scanner(System.in);  
    System.out.println("Bubble Sort");         
System.out.print("Enter number of elements: ");  
    int n = scanner.nextInt();       
    int[] arr 
= new int[n];          
System.out.println("Enter elements:");    
for (int i = 0; i < n; i++) {            
	arr[i] = 
scanner.nextInt();   
    }  
    System.out.println("Unsorted Array:");     
    for (int i = 0; i < n; i++) {            
    	System.out.print(arr[i] + " ");  
    }  
    System.out.println();  
    for (int i = 0; i < n - 1; i++) {          
    	for (int j = 0; 
    			j < n - i - 1; j++) {                
    		if (arr[j] > arr[j + 1]) {                   
    			int temp = arr[j];                    
    			arr[j] = arr[j + 1];                  
    			arr[j + 1] = temp;  
            }  
        }  
    }  
    System.out.println("Sorted Array:");        
    for (int i = 0; i < n; i++) {     
    	System.out.print(arr[i] + " ");  
    }  
    }  


}

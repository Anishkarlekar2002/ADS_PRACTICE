package mypack;

public class HashTable {
	private static final int SIZE = 10;  
	private int[] arr; 
	public HashTable() { 
		arr = new int[SIZE];
		for (int i = 0; i < SIZE; i++) { 
			arr[i] = -1;  
			} 
		}  
	private int hashFunction(int key) { 
		return 
	key % SIZE; }  
	public void insert(int key) {  
	int index = hashFunction(key); 
	int i = 0;  
	while (arr[(index + i) % SIZE] != -1 && arr[(index + i) % SIZE] != -2 && arr[(index + i)  
	% SIZE] != key) {  i++; }  
	if (arr[(index + i) % SIZE] == key) {
		System.out.println("\nElement already exists in the hash table\n");  
	} else 
	{  arr[(index + i) % SIZE] = key; 
	} 
	} public void remove(int key) {  
	int index = hashFunction(key);
	int i = 0;  
	while (arr[(index + i) % SIZE] != -1) {
		if (arr[(index + i) % SIZE] == key) {
			arr[(index + i) % SIZE] = -2;  
	System.out.println("Element deleted from hash table");
	return; } i++;  
	}  
	System.out.println("Element not found in the hash table");  
	} public void display(){ 
		for (int i = 0; i < SIZE; i++) {
			if (arr[i] != -1 && arr[i] != -2) {  
	System.out.println("Index " + i + ": " + arr[i]);  	
	}
		}
		
	} public static void main(String[] args) {
		HashTable ht = new HashTable();
		ht.insert(15);
		ht.insert(20);
		ht.insert(25);
		ht.insert(35);
		ht.display();
		ht.remove(20);
		ht.display();
		ht.remove(10); 
		ht.display();
		ht.insert(65);  
	ht.display(); 
	} 
}

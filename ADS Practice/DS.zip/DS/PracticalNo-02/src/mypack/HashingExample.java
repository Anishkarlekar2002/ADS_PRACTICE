package mypack;

public class HashingExample {
	private static final int SIZE = 10;
	private int[] hashTable;
	public HashingExample() {
		hashTable = new int[SIZE];
		for (int i = 0; 
				i < SIZE; i++) {
			hashTable[i] = -1;
			}
		}
	public void insert(int value) {
		int key = value % SIZE;
		while (hashTable[key] != -1) { 
			key = (key + 1) % SIZE;  
		}  
		hashTable[key] = value;  
		System.out.println("Inserted " + value + " at position " + key);  
		} 
	public void delete(int value) { 
		int key = value % SIZE; while (hashTable[key] != value) { 
			key = (key + 1) % SIZE; if (hashTable[key] 	== -1) { 
				// Value not found 
		System.out.println("Element not found."); 
		return;  
		}
			}  
		hashTable[key] = -1;  
		System.out.println("Deleted element " + value);  
		} public void printHashTable() {
			for (int i = 0; i < SIZE; i++) { 
		System.out.print(hashTable[i] + "\t");  
		}  
		System.out.println();  
		}  
		public static void main(String[] args) {  
		HashingExample hash = new HashingExample();
		hash.insert(20);
		hash.printHashTable();
		hash.insert(30);
		hash.printHashTable();
		hash.insert(40);
		hash.printHashTable();
		hash.insert(50);
		hash.printHashTable();
		hash.insert(20);
		hash.printHashTable();
		hash.insert(8);
		hash.printHashTable();
		hash.delete(40);  
		hash.printHashTable();
		}


}

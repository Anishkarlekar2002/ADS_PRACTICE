package myPack;

public class Node4 {
	int data; 
	Node4 next; 
	 
 	public Node4(int data) {  	 	
 		this.data = data; 
 	 	this.next = null; 
 	} 


}

package myPack;

public class Node5 {
	int data; 
	Node5 next; 
	 
 	public Node5(int data) {  	 	
 		this.data = data; 
 	 	this.next = null; 
 	} 

}

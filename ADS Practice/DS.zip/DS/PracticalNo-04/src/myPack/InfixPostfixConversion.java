package myPack;
import java.util.*; 

public class InfixPostfixConversion {
    // Method to convert infix expression to postfix expression    
	public static String infixToPostfix(String infix) {      
		// The output will be represented as postfix 
    StringBuilder postfix = new StringBuilder(); 
    // Initialize the stack to store the operators 
   // Stack<Character> stk = new Stack<>(); 
    Stack stk=new Stack(); 

    for (char c : infix.toCharArray()) { 
        // If the encountered character is an operand, add it to the output        
    	if (Character.isLetterOrDigit(c)) {             
    		postfix.append(c); 
        }  
        // If the encountered character is'(', push it to the stack            
    	else if (c == '(') {                 
    		stk.push(c); 
        }  
        // If the encountered character is ')', pop the stack until '(' is encountered        
    	else if (c == ')') {               
    		while (!stk.isEmpty() && stk.peek() != '(') {                  
    			postfix.append(stk.pop()); 
            } 
            stk.pop(); // Discard   '(' by popping it from the stack 
        }  
        // For operators, handle precedence 
        else { 
            while (!stk.isEmpty() && precedence(stk.peek()) >= precedence(c)) {                
            	postfix.append(stk.pop()); 
            } 
            stk.push(c); // Push the current operator to the stack 
        } 
    } 
    // After traversing the entire string, pop the stack and add to the output         
    while (!stk.isEmpty()) {             
    	postfix.append(stk.pop()); 
    } 
    return postfix.toString(); 
} 
// Method to check the precedence of the operator   
	public static int precedence(char operator) {       
		switch (operator) {      
		case '+':        
			case '-': 
            return 1;         
            case '*':      
            	case '/': 
            return 2;       
            default:     
            	return 0; 
    } 
}  
// Main function 
	public static void main(String[] args) { 
    System.out.println("Enter an Infix expression:"); 
    Scanner sc = new Scanner(System.in);  
    String infix = sc.next();    
    sc.close(); 
    String postfix = infixToPostfix(infix); 
    System.out.println("Postfix Expression: \n" + postfix); 
}

	

}

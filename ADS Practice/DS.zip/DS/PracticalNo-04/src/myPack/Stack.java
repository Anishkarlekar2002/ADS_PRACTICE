package myPack;
import java.io.*; 
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Stack {
	char[] a = new char[100];  
	int top = -1;   
	void push(char c) { 
        try {       
        	a[++top] = c; 
        } catch (ArrayIndexOutOfBoundsException e) { 
           System.out.println("Stack full, no room to push, size=100"); 
            System.exit(0); 
        } 
    }     char pop() {    
    	return a[top--]; 
    } 
    boolean isEmpty() {       
    	return top == -1; 
    }     char peek() {      
    	return a[top]; 
    } 


public class InfixToPostfix {
	static Stack operators = new Stack();   
	public static void main(String[] argv) throws IOException { 
        String infix; 
 
        // Create an input stream object 
        BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in)); 
        // Get input from user 
        System.out.print("\nEnter the infix expression you want to convert: ");      
        infix = keyboard.readLine(); 
        // Output as postfix 
        System.out.println("Postfix expression for the given infix expression is: " + toPostfix(infix)); 
    } 
    private static String toPostfix(String infix) {      
    	// Converts an infix expression to postfix       
    	char symbol;       
    	String postfix = "";        
    	for (int i = 0; i < infix.length(); ++i) {          
    		symbol = infix.charAt(i); 
            // If it's an operand, add it to the string     
    		if (Character.isLetterOrDigit(symbol)) {               
    			postfix = postfix + symbol; 
            } else if (symbol == '(') { 
                // Push'('         
            	operators.push(symbol);        
            	} else if (symbol == ')')
            	{             
            		// Pop everything back to'('              
            		while (operators.peek() != '(') {            
            			postfix = postfix + operators.pop(); 
                } 
                operators.pop();
                // Remove  '(' 
            } else { 
                // Print operators occurring before it that have greater precedence 
                while (!operators.isEmpty() && !(operators.peek() == '(') &&                      
                		prec(symbol) <= prec(operators.peek())) {                   
                	postfix = postfix + operators.pop(); 
                } 
                operators.push(symbol); 
            } 
        } 
        // Pop all remaining operators   
    	while (!operators.isEmpty()) {        
    		postfix = postfix + operators.pop(); 
        }         return postfix; 
    }     static int prec(char x) {   
    	if (x == '+' || x == '-') return 1;    
    	if (x == '*' || x == '/' || x == '%') return 2;        
    	return 0; 
    } 

}

}



package myPack;
import java.util.Arrays; 

public class DigitExtractionHashTable {
	private static final int SIZE = 10;  
	private int[] hashTable; 
	 
    // Constructor to initialize the hash table with -1 indicating an empty slot    
	public DigitExtractionHashTable() {      
		hashTable = new int[SIZE]; 
        Arrays.fill(hashTable, -1); 
    } 
 
    // Insert key using digit-extraction hashing and linear probing for collision resolution  
	public void insert(int key, int digitPosition) { 
		
        int numDigits = (int) Math.log10(key) + 1;  // Count total number of digits in the key 
 
        // Check if the specified digit position is valid 
        if (digitPosition > numDigits || digitPosition <= 0) {       
        	System.out.println("Invalid digit position!");            
        	return; 
        }  
        // Extract the specified digit and use it as the index 
        int index = (key / (int) Math.pow(10, numDigits - digitPosition)) % 10; 
 
        // Resolve collisions using linear probing      
        while (hashTable[index] != -1) { 
            System.out.println("\nCollision found at address " + index + " for " + key);  
            System.out.println("Searching next empty slot using linear probing!");       
            index = (index + 1) % SIZE; 
        } 
 
        System.out.println("\nNo collision at address " + index + " for " + key);        
        hashTable[index] = key; 
    } 
 
    // Display the hash table   
	public void display() { 
        System.out.println("\nHash Table:");     
        for (int i = 0; i < SIZE; i++) {         
        	if (hashTable[i] != -1) { 
                System.out.println("Index " + i + ": " + hashTable[i]); 
            } else { 
                System.out.println("Index " + i + ": NULL"); 
            } 
        } 
    } 
 
    // Main method to test the hash table    
	public static void main(String[] args) { 
        int[] keys = {12345, 67890, 13579, 24680, 98765, 43210, 56789, 10234}; // keys to insert 
        int digitPosition = 3; 
 
        DigitExtractionHashTable ht = new DigitExtractionHashTable();  
        System.out.println("Hashing using Digit Extraction (place of digit is " + digitPosition + "):"); 
 
        for (int key : keys) { 
            ht.insert(key, digitPosition); 
        } 
 
        ht.display(); 
    } 
} 
 
 
 
 




package myPack;
import java.util.Arrays; 

public class HashTable {
	private static final int SIZE = 10;  
	private int[] hashTable; 
	 
    // Constructor to initialize the hash table with -1 indicating an empty slot  
	public HashTable() {       
		hashTable = new int[SIZE]; 
        Arrays.fill(hashTable, -1); 
    } 
 
    // Insert key using linear probing  
	public void insertLinearProbing(int key) {       
		int index = key % SIZE; 
         
        // Check for collision and apply linear probing if necessary 
        while (hashTable[index] != -1) { 
            System.out.println("\nCollision found at address " + index + " for " + key);          
            System.out.println("Searching next empty slot using linear probing!");             
            index = (index + 1) % SIZE; 
        } 
         
        System.out.println("\nNo collision at address " + index + " for " + key);     
        hashTable[index] = key; 
    } 
 
    // Display the hash table     
	public void displayProbing() {    
		System.out.println("\nHash Table:");     
		for (int i = 0; i < SIZE; i++) {            
			if (hashTable[i] != -1) { 
                System.out.println("Index " + i + ": " + hashTable[i]); 
            } else { 
                System.out.println("Index " + i + ": NULL"); 
            } 
        } 
    } 
    // Main method to test the hash table 
	public static void main(String[] args) { 
        int[] keys = {25, 36, 47, 55, 63, 75, 84, 92}; // keys to insert 
        HashTable ht = new HashTable(); 
         
        System.out.println("Hashing using Linear Probing:"); 
        for (int key : keys) {             ht.insertLinearProbing(key); 
        } 
        ht.displayProbing(); 
    } 
}  



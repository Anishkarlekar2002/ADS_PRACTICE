package myPack;

import java.util.Scanner;

public class BubbleSort {
    // Method to perform bubble sort
	public static void bubbleSort(long[] list, int size) {  
		long hold;   
		boolean flag; 
	 
    for (int holdIndex = 0; holdIndex < size - 1; holdIndex++) {        
    	flag = false; // no swap initially            
    	for (int walker = 0; walker < size - holdIndex - 1; walker++) {            
    		if (list[walker] > list[walker + 1]) { 
                // Swap elements           
    			long temp = list[walker];              
    			list[walker] = list[walker + 1];         
    			list[walker + 1] = temp;                 
    			flag = true; // swap occurred 
            }             }             if (!flag) { 
            // If no swap, array is already sorted  
            	break; 
        } 
         
        // Display the array after each pass 
        System.out.print("\nPass " + (holdIndex + 1) + ": ");            
        for (int i = 0; i < size; i++) { 
            System.out.print(list[i] + " "); 
        } 
    } 
} 
public static void main(String[] args) {     
	Scanner scanner = new Scanner(System.in);  	
	int size = 15;     long[] num = new long[size]; 

                                            
    // Input array elements 
    System.out.println("Enter 15 elements:");  
    for (int i = 0; i < size; i++) {           
    	num[i] = scanner.nextLong(); 
    } 
    // Display unsorted array        
    System.out.print("\nUnsorted array: ");        
    for (long element : num) { 
        System.out.print(element + " "); 
    } 
    // Perform bubble sort  
    bubbleSort(num, size); 
    // Display sorted array 
    System.out.print("\n\nSorted array: ");  
    for (long element : num) { 
        System.out.print(element + " "); 
    } 
    scanner.close(); 
} 
} 



package myPack;

import java.util.Scanner;

public class SequentialSearch {
	public static void main(String[] args) { 
        Scanner scanner = new Scanner(System.in); 
 
        // Input array elements 
        System.out.print("Enter the number of elements: ");    
        int n = scanner.nextInt();     
        int[] array = new int[n]; 
 
        System.out.println("Enter the elements:");      
        for (int i = 0; i < n; i++) {         
        	array[i] = scanner.nextInt(); 
        } 
 
        // Input key to search 
        System.out.print("Enter the key to search: ");    
        int key = scanner.nextInt(); 
 
        // Perform sequential search 
        boolean found = false;       
        for (int i = 0; i < n; i++) {           
        	if (array[i] == key) { 
                System.out.println("Key found at index: " + i);     
                found = true;      
                break; 
            } 
        } 
 
                                                           
        if (!found) { 
            System.out.println("Key not found in the array."); 
        } 
 
        scanner.close(); 
    } 


}



package myPack;

import java.util.Scanner;

public class RecursiveBinarySearch {
    // Recursive binary search method   
	public static int binarySearch(int[] num, int low, int high, int key) {    
		if (low <= high) {            
			int mid = (low + high) / 2;
			// Calculate mid index 
	 
    if (num[mid] == key) {        
    	return mid; 
    	// Key found 
    } 
    if (num[mid] < key) { 
        return binarySearch(num, mid + 1, high, key); 
        // Search in the right half 
    } else { 
        return binarySearch(num, low, mid - 1, key); 
        // Search in the left half 
    } 
} 
return -1; // Key not found 
} 
                                                           

public static void main(String[] args) { 
Scanner scanner = new Scanner(System.in); 

System.out.print("Enter the array size: ");      
int size = scanner.nextInt(); 
 
int[] num = new int[size]; 
 
System.out.print("Enter the sorted elements: "); 
for (int i = 0; i < size; i++) {         
	num[i] = scanner.nextInt(); 
} 
 
System.out.print("Enter the element to be searched: ");   
int key = scanner.nextInt(); 
 
// Perform binary search    
int result = binarySearch(num, 0, size - 1, key); 
 
if (result != -1) { 
    System.out.println("Element found at index: " + result); 
} else { 
    System.out.println("Element not found in the array!"); 
} 

scanner.close(); 
} 
} 




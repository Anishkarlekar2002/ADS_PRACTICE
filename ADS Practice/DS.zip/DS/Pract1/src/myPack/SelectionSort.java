package myPack;

import java.util.Scanner;

public class SelectionSort {
    // Method to perform selection sort  
	public static void selectionSort(long[] list, int size) {  
		for (int hold = 0; hold < size - 1; hold++) { 
    int pos = hold; 

    // Find the minimum element in the unsorted portion of the array    
    for (int walker = hold + 1; walker < size; walker++) { 
        if (list[walker] < list[pos]) { 
            pos = walker; // Update the position of the minimum element 
        } 
    } 

    // Swap the found minimum element with the first element of the unsorted part  
    if (hold != pos) {             
    	long temp = list[pos];              
    	list[pos] = list[hold]; 
        list[hold] = temp; 
    } 

    // Display the array after each pass 
    System.out.print("\nPass " + (hold + 1) + ": "); 
    for (int i = 0; i < size; i++) {            
    	System.out.print(list[i] + " "); 
    } 
} 
} 

public static void main(String[] args) { 
Scanner scanner = new Scanner(System.in); 

int size = 10; 
long[] num = new long[size]; 

// Input array elements 
System.out.println("Enter 10 elements:"); 
for (int i = 0; i < size; i++) { 
    num[i] = scanner.nextLong(); 
} 

// Display unsorted array 
System.out.print("\nUnsorted array: ");    
for (long element : num) {         
	System.out.print(element + " "); 
} 

// Perform selection sort      
selectionSort(num, size); 

// Display sorted array 
System.out.print("\n\nSorted array: ");    
for (long element : num) {          
	System.out.print(element + " "); 
} 

scanner.close(); 
} 
} 




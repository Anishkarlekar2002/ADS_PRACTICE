package myPack;

import java.util.Scanner;

public class InsertionSort {    
	// Method to perform insertion sort     
	public static void insertionSort(int[] list, int n) {  
		for (int key = 1; key < n; key++) {    
			int hold = list[key];         
			int walker = key - 1; 
	 
    // Move elements that are greater than 'hold' one position ahead  
			while (walker >= 0 && hold < list[walker]) {             
				list[walker + 1] = list[walker];           
				walker--; 
    } 
    list[walker + 1] = hold; 

    // Display the array after each pass           
    System.out.print("\nPass " + key + ": ");           
    for (int i = 0; i < n; i++) { 
        System.out.print(list[i] + " "); 
    } 
} 
} 

public static void main(String[] args) { 
Scanner scanner = new Scanner(System.in); 

int size = 10; 
int[] num = new int[size]; 

// Input array elements 
System.out.println("Enter 10 elements:"); 
for (int i = 0; i < size; i++) {         
	num[i] = scanner.nextInt(); 
} 

// Display unsorted array 
System.out.print("\nUnsorted array: ");       
for (int element : num) { 
    System.out.print(element + " "); 
} 

// Perform insertion sort        
insertionSort(num, size); 

// Display sorted array 
System.out.print("\n\nSorted array: ");    
for (int element : num) { 
    System.out.print(element + " "); 
} 
scanner.close(); 
} 
} 

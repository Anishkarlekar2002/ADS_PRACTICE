package myPack;
import java.io.File; 
import java.io.FileNotFoundException; 
import java.util.Scanner; 
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ShellSort {

    // Method to perform shell sort   
    public static void shellSort(int[] arr, int n) {  
        int pass = 1; 
        for (int gap = n / 2; gap > 0; gap /= 2) { 
            for (int i = gap; i < n; i++) {          
                int temp = arr[i]; 
                int j;  
                // Shift elements of arr[0..i-gap] that are greater than temp   
                for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) {  
                    arr[j] = arr[j - gap]; 
                } 
                arr[j] = temp; 
            } 

            // Print array after each pass 
            System.out.print("\nGap = " + gap + "\nPass " + pass + ": ");  
            for (int k = 0; k < n; k++) {              
                System.out.print(arr[k] + " "); 
            } 
            pass++; 
        } 
    }

    public static void main(String[] args) { 
        // File to read from    
        String filename = "num.txt";     
        int size = 15; 
        int[] arr = new int[size]; 

        // Read numbers from file   
        try (Scanner scanner = new Scanner(new File(filename))) {   
            for (int i = 0; i < size && scanner.hasNextInt(); i++) {     
                arr[i] = scanner.nextInt(); 
            } 
        } catch (FileNotFoundException e) { 
            System.out.println("Failed to open file: " + filename);  
            return; 
        } 

        // Display unsorted array 
        System.out.print("Unsorted array: "); 
        for (int i = 0; i < size; i++) {      
            System.out.print(arr[i] + " "); 
        } 

        // Perform shell sort 
        shellSort(arr, size); 

        // Display sorted array 
        System.out.print("\n\nSorted array: "); 
        for (int i = 0; i < size; i++) {       
            System.out.print(arr[i] + " "); 
        } 
    } 
}

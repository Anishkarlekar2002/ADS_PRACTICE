package bst;

public class Node {
	Node right,left;
	int data;

	public Node(int data) {
		right=left=null;
		this.data= data;	

	}
}

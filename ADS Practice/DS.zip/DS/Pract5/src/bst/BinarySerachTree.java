package bst;

import java.util.Scanner;


public class BinarySerachTree {
	private BinarySerachTree root;
	private int data;
	private BinarySerachTree right;
	private BinarySerachTree left;
	static int count =0;

	public BinarySerachTree() {
		this.root = null;

	}
	public static int nodeCounts() {
		return count;
	}

	public void insertNode(int val) {
	BinarySerachTree newNode = new BinarySerachTree();
	if( root == null) {
		root = newNode;
		count ++;
	}else {

		BinarySerachTree trav = root;
		BinarySerachTree hold = null;

		while(trav !=null) {
			hold= trav;
			if(val > trav.data) {
				trav = trav.right;
			}
			else if(val < trav.data){
				trav = trav.left;
			}
			else {
				System.out.println("Duplicate data");
				return;
			}
		}
		if(val > hold.data)
			hold.right = newNode ;
		else
			hold.left = newNode;
		count++;

	}
}
public void inorder(BinarySerachTree root) {
	if(root != null) {
		inorder(root.left);
		System.out.print(root.data + " ");
		inorder(root.right);
	}
}
public void inorder() {
	inorder(root);
}
public void preorder(BinarySerachTree root) {
	if(root!=null) {
		if(root != null) {
			System.out.print(root.data + " ");
			preorder(root.left);
			preorder(root.right);
		}
	}

}
public void preorder() {
	preorder(root);
}

public void postorder(BinarySerachTree root) {
	if(root!=null) {
		if(root != null) {
			postorder(root.left);
			postorder(root.right);
			System.out.print(root.data + " ");
		}
	}

}
public void postorder() {
	postorder(root);
}
public void smallest() {
	BinarySerachTree trav = root;
	if(trav == null) {
		System.out.println("Tree is empty !");
		return;
	}
	while(trav.left !=null) 
		trav =trav.left;

	System.out.println("Smallest Node is: " + trav.data);
}

public void largest() {
	BinarySerachTree trav = root;
	if(trav == null) {
		System.out.println("Tree is empty !");
		return;
	}
	while(trav.left !=null) 
		trav =trav.right;

	System.out.println("largest Node is: " + trav.data);
}
 public static void main(String[] args) {
	 BinarySerachTree bt = new BinarySerachTree();
        Scanner sc = new Scanner(System.in);
    	int data;	        
        int choice;
        System.out.print("\nBinary Search Tree\n\n");
    	do
    	{
    		System.out.print("\n1.Insert Node\n");
    		System.out.print("2.InOrder Traversal\n");
    		System.out.print("3.PreOrder Traversal\n");
    		System.out.print("4.PostOrder Traversal\n");
    		System.out.print("5.Smallest Node\n");
    		System.out.print("6.Largest Node\n");
    		System.out.print("7.Count Nodes\n");
    		System.out.print("10.Exit\n");
    		System.out.print("Enter your choice : ");
    		choice = sc.nextInt();
    		switch (choice)
    		{
    		case 1: System.out.print("\nInsert Node - Enter data : ");
    		data= sc.nextInt();
			bt.insertNode(data);
			break;
	case 2: System.out.print("\nInOrder Traversal : ");
			bt.inorder();
			break;
	case 3: System.out.print("\nPreOrder Traversal : ");
			bt.preorder();
			break;
	case 4: System.out.print("\nPostOrder Traversal : ");
			bt.postorder();
			break;
	case 5: System.out.print("\nSmallest node is : ");
			bt.smallest();
			break;
	case 6: System.out.print("\nLargest node is : ");
			bt.largest();
			break;  
	case 7: System.out.print("\nTotal node count : " + nodeCounts());
			break;
	case 10: System.out.println("Exiting the program.");  
			break;
	default:
		System.out.print("\nWrong choice! \n");
		
	} 
}while(choice!=10); 
sc.close(); 
    }  

}

package heap;

public class MaxHeap {
	Node head,tail;
	public MaxHeap() {
		this.head = null;
		this.tail = null;
	}
	
	private void reheapUp(Node node) {
		Node parent = getParent(node);
		
		while(parent != null && node.data > parent.data) {
			
			int temp = node.data;
			node.data =  parent.data;
			parent.data = temp;
			
			node=parent;
			parent = getParent(node);
		}
	}
	
	private void reheapDown(Node node) {
		while(node != null) {
			Node leftChild = node.next;
			Node rightChild = (leftChild != null) ? leftChild.next : null;
			if(leftChild == null) {
				break;
			}
			
			Node maxChild = leftChild;//chnage
			if(rightChild != null && rightChild.data > leftChild.data) {
				//change
				maxChild = rightChild;//change
			}
			
			if(node.data >= maxChild.data) {
			
				break;
				
			}
			int temp = node.data;
			node.data = maxChild.data;//change
			maxChild.data = temp; //chnage
			node = maxChild; //change
		}
	}
	public void insert(int data) {
		Node newNode = new Node(data);
		if(head == null) {
			head = newNode;
			tail = newNode;
			
		}else {
			tail.next = newNode;
			newNode.prev = tail;
			tail = newNode;
			reheapUp(newNode);
		}
	}
	
	public void delete() {
		if(head == null) {
			System.out.println("Heap is empty! ");
			return;
		}
		Node lastNode = tail;
		head.data = lastNode.data;
		if(tail.prev != null) {
			tail = tail.prev;
			tail.next = null;
		}else {
			head = null;
		}
		reheapDown(head);
		
	}
	private Node getParent(Node node) {
		return node.prev;
	}
	public void printHeap() {
		Node temp = head;
		while(temp != null) {
			System.out.print(temp.data + " ");
			temp =  temp.next;
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		MaxHeap maxHeap = new MaxHeap();

		System.out.println("\nInserting values into MaxHeap :");
		maxHeap.insert(10);
		maxHeap.insert(20);
		maxHeap.insert(5);
		maxHeap.insert(8);
		maxHeap.printHeap(); 
		System.out.println("Deleting root node from maxHeap: ");
		maxHeap.delete();
		maxHeap.printHeap(); 
				
	}


}

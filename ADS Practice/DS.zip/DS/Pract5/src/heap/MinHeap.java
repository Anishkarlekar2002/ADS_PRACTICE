package heap;

public class MinHeap {
    Node head, tail;
    public MinHeap() {
        this.head = null;
        this.tail = null;
    }
    private void reheapUp(Node node) {
        Node parent = getParent(node);

        while (parent != null && node.data < parent.data) { 
            int temp = node.data;
            node.data = parent.data;
            parent.data = temp;

            node = parent;
            parent = getParent(node);
        }
    }
    private void reheapDown(Node node) {
        while (node != null) {

            Node leftChild = node.next;

            Node rightChild = (leftChild != null) ? leftChild.next : null;
            if (leftChild == null) {
                break;
            }

            Node minChild = leftChild; 

            if (rightChild != null && rightChild.data < leftChild.data) {
                minChild = rightChild; 
            }
            if (node.data <= minChild.data) {
                break;
            }
            int temp = node.data;
            node.data = minChild.data;
            minChild.data = temp;

            node = minChild;
        }
    }

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
            reheapUp(newNode);
        }
    }

    public void delete() {
        if (head == null) {
            System.out.println("Heap is empty!");
            return;
        }
        Node lastNode = tail;
        head.data = lastNode.data;

        if (tail.prev != null) {
            tail = tail.prev;
            tail.next = null;
        } else {
            head = null;
        }      
        reheapDown(head);
    }
    private Node getParent(Node node) {
        Node temp = head;
        int index = 0;
        while (temp != node) {
            temp = temp.next;
            index++;
        }

        int parentIndex = (index - 1) / 2;
        temp = head;

        for (int i = 0; i < parentIndex; i++) {
            temp = temp.next;
        }
        return temp;
    }
    public void printHeap() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
    public static void main(String[] args) {
        MinHeap minHeap = new MinHeap();
        System.out.println("\nInserting values into MinHeap:");
        minHeap.insert(10);
        minHeap.insert(20);
        minHeap.insert(5);
        minHeap.insert(8);
        minHeap.printHeap(); // Print the heap in valid MinHeap order
        System.out.println("Deleting root node from MinHeap:");
        minHeap.delete();
        minHeap.printHeap(); // Should print the heap after root node deletion
    }


}

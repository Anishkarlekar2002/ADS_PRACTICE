package heap;

public class Node {
	Node prev,next;
	int data;

	public Node(int data) {
		prev=next=null;
		this.data= data;	

	}


}

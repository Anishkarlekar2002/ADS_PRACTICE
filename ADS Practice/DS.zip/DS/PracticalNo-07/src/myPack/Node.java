package myPack;
//Binary Search Tree
class Node {
int key;
Node left, right;

public Node(int item) {
key = item;
left = right = null;
}
}

class BinarySearchTree {
Node root;

public BinarySearchTree() {
root = null;
}

// Insertion /create operation
void insert(int key) {
root = insertRec(root, key);
}

Node insertRec(Node root, int key) {


if (root == null) {
root = new Node(key);
return root;
}

if (key < root.key)
root.left = insertRec(root.left, key);
else if (key > root.key)
root.right = insertRec(root.right, key);

return root;
}
// Inorder traversal
void inorder() {
inorderRec(root);
System.out.println("\n");
}

void inorderRec(Node root) {
if (root != null) {
inorderRec(root.left);
System.out.print(root.key + " ");
inorderRec(root.right);
}
}

// Preorder traversal
void preorder() {


preorderRec(root);
System.out.println("\n");

}

void preorderRec(Node root) {
if (root != null) {
System.out.print(root.key + " ");
preorderRec(root.left);
preorderRec(root.right);
}
}

// Postorder traversal
void postorder() {
postorderRec(root);
System.out.println("\n");
}

void postorderRec(Node root) {
if (root != null) {
postorderRec(root.left);
postorderRec(root.right);
System.out.print(root.key + " ");
}
}
// Search operation
boolean search(int key) {
return searchRec(root, key);


}

boolean searchRec(Node root, int key) {
if (root == null)
return false;
if (root.key == key)
return true;
if (root.key < key)
return searchRec(root.right, key);
return searchRec(root.left, key);
//display minimum value
int minValue(Node root) {
int minv = root.key;
while (root.left != null) {
minv = root.left.key;
root = root.left;
}
return minv;
}
//count number of nodes
int totalnodes(Node root)
{
if(root==null)
return 0;
int l=totalnodes(root.left);
int r=totalnodes(root.right);
return l+r+1;
}
//display minimum value in BST


/*int minValue(Node root) {
int minv = root.key;
while (root.left != null) {
minv = root.left.key;
root = root.left;
}
return minv;
}
*/
}
// Driver Class

// Main Function
public static void main(String[] args) {
BinarySearchTree tree = new BinarySearchTree();
// Inserting elements
tree.insert(20);
tree.insert(10);
tree.insert(30);
tree.insert(100);
tree.insert(40);
tree.insert(70);
tree.insert(60);
tree.insert(80);
System.out.println("total nodecount= " +tree.totalnodes(tree.root));
System.out.println("minimum value of node in tree= " +tree.minValue(tree.root));

System.out.println("Inorder traversal:");
tree.inorder();


System.out.println("Preorder traversal:");
tree.preorder();
System.out.println("Postorder traversal:");
tree.postorder();
// Searching for an element
int searchKey =70;
System.out.println("Is " + searchKey + " present in the tree? " +
tree.search(searchKey));

// Traversals
//System.out.println("Preorder traversal:");
//tree.preorder();

//System.out.println("Postorder traversal:");
//tree.postorder();
}
}
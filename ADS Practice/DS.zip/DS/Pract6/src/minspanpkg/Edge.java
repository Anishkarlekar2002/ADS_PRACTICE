package minspanpkg;


public class Edge {
	int src,dest,weight;
	Edge(int src,int des ,int weight)
	{ this.src=src; 
	this.dest=des;
	this.weight=weight;
	}
	}
	
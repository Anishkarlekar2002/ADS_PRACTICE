package myPack;

import java.util.Scanner;

public class MyStack3 {
	private int maxSize; 
	private int top;    
	private char[] stackArray; 
	public MyStack3(int size) {      
		maxSize = size;        
		stackArray = new char[maxSize]; 
    top = -1; 
} 
public void push(char value) { 
    if (isFull()) { 
        System.out.println("Stack is full! Cannot push element!"); 
    } else { 
        stackArray[++top] = value; 
    } 
} 
public char pop() {     
	if (isEmpty()) { 
        System.out.println("Stack is empty! Cannot pop element!"); 
        return 'F';         
        } else { 
        return stackArray[top--]; 
    } 
} 
public char peek() {   
	if (isEmpty()) { 
        System.out.println("Stack is empty!");    
        return 'F';       
        } else { 
        return stackArray[top]; 
    } 
} 
public boolean isFull() { 
    return (top == maxSize - 1); 
} 
public boolean isEmpty() {  
	return top == -1; 
} 
public void displayAll() {  
	if (top == -1) { 
        System.out.println("\nStack is empty! No elements to display!\n"); 
    } else { 
        System.out.println("\nElements in the stack are: "); 
        for (int i = top; i >= 0; i--) { 
            System.out.print(stackArray[i] + " "); 
        } 
        System.out.println(""); 
    } 
} 

public class InfixToPostfix {  
	int prec(char c) {      
		if (c == '^')       
			return 3;       
		else if (c == '/' || c == '*')       
			return 2; 
    else if (c == '+' || c == '-')  
    	return 1;        
    else             
    	return -1; 
} 
void infixToPostfix(String s, MyStack2 st) {      
	StringBuilder result = new StringBuilder();   
	for (int i = 0; i < s.length(); i++) {        
		char c = s.charAt(i); 
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
        	result.append(c);           
        else if (c == '(')             
        	st.push('(');       
        else if (c == ')') {          
        	while (st.peek() != '(') { 
                result.append(st.pop()); 
            }                 st.pop(); 
        }             else {   
        	while (!st.isEmpty() && (prec(c) < prec(st.peek()) || prec(c) == prec(st.peek()))) {     
        		result.append(st.pop()); 
            } 
            st.push(c); 
        } 
    } 




    while (!st.isEmpty()) { 
        result.append(st.pop()); 
    } 
    System.out.println(result.toString()); 
} 

public static void main(String[] args) {        
	Scanner sc = new Scanner(System.in); 
    MyStack2 st = new MyStack2(15); 
    System.out.println("Please enter infix expression :"); 
    String exp = sc.nextLine(); 
    InfixToPostfix ip = new InfixToPostFix();
    ip.infixToPostfix(exp, st);   
    sc.close(); 
} 
} 
}


package myPack;

import java.util.Scanner;

public class MyQueue {
	 int QUEUESIZE,arr[],q_front,q_rear;  
	 public MyQueue(int size) { 
	 	 	 QUEUESIZE=size;  	 	 
	 	 	 arr=new int[QUEUESIZE];  	 	 	
	 	 	 q_front=0; 
	 	 	 q_rear=-1; 
	 	} 
	 public void enqueue(int val) {  	 	
		 arr[++q_rear]=val; 
	 }
	 
	 public int dequeue(int val) {  	
		 int q_element=arr[q_front];  	 
		 q_front=q_front+1; 
	 	 return q_element;  
	 } 
	 public boolean isEmpty() {  	 	 	
		 if(q_rear==-1 || q_front>q_rear ) { 
	 	 	 	return true;  	 	 	}
		 else {  	 	 	 
			 return false; 
	 	 	} 
	 	} 
	 public boolean isFull() { 
	 	 	if(q_rear==QUEUESIZE-1) { 
	 	 	 	return true;  	 	 	}
	 	 	else {  	 	 	 	
	 	 		return false; 
	 	 	} 
	 	} 
	 public int size() { 
	 	 return q_rear+1; 
	 } 
	 void displayAll() { 
	 	 	if(isEmpty()) { 
	 	 	 	System.out.println("Queue is Empty!No elements to Display\n"); 
	 	 	} 
 	 	 	else{ 
 	 	 	 	System.out.println("Elements in Queue are: ");  
 	 	 	 	for(int i=q_front;i<=q_rear;i++) { 
 	 	 	 	 	System.out.print(arr[i]+" "); 
 	 	 	 } 
 	 	 	 	System.out.println(""); 
 	 	 	} 
	 } 

//	public class QueueDemo {  
		public static void main(String[] args) { 
	}
	 	 	// TODO Auto-generated method stub 
	 	 	Scanner sc=new Scanner(System.in);  	
	 	 	MyQueue st=new MyQueue(5); 
	 	 	   int val;  	 
	 	  int choice; 

	 	 	   do { 
	 	 	 	   System.out.println("\n 1.Enqueue"); 
	 	 	 	   System.out.println(" 2.Dequeue"); 
	 	 	 	   System.out.println(" 3.Display"); 
	 	 	 	   System.out.println(" 4.Exit"); 
	 	 	 	   System.out.println("Enter your choice: "); 
	 	 	 	   choice=sc.nextInt(); 
	 	 	 	   switch(choice)  
	 	 	 	   { 
	 	 	 	 	   case 1: 
	 	 	 	 	 	   if(st.isFull()) { 
	 	 	 	 	 	 	   System.out.println("\nQueue is Full "); 
	 	 	 	 	 	   }else { 
	 	 	 	 	 	 	   System.out.println("\nEnter Value to be Entered: "); 
	 	 	 	 	 	 	   val=sc.nextInt(); 
	 	 	 	 	 	 	   st.enqueue(val); 
	 	 	 	 	 	   } 
	 	 	 	 	 	   break;  	 	 	 	
	 	 	 	 	 	   case 2: 
	 	 	 	 	 	   if(st.isEmpty()) { 
	 	 	 	 	 	 	   System.out.println("\nQueue is Empty !value cannot be removed "); 
	 	 	 	 	 	   }else { 
	 	 	 	 	 	   val=st.dequeue(3); 
	 	 	 	 	 	   System.out.println("\n Popped element is:"+val); 
	 	 	 	 	 	   } 
	 	 	 	 	 	   break;  	
	 	 	 	 	 	   case 3: 
	 	 	 	 	 	   st.displayAll();  	 
	 	 	 	 	 	   break;  	 	 	 	
	 	 	 	 	 	   default: 
	 	 	 	 	 		System.out.println("\n Wrong choice!\n"); 	 	   
	 	 	    	}//End of Switch 
	 	 	   }while(choice!=5); 
	} 

}





package myPack;
import java.util.Scanner;

public class MyCircularQueue {
	int QUEUESIZE,arr[],q_front,q_rear; 
	 public MyCircularQueue(int size) { 
	 	 	 QUEUESIZE=size;  	 	 	
	 	 	 arr=new int[QUEUESIZE];  	 	 	
	 	 	 q_front=-1; 
	 	 	 q_rear=-1; 
	 	} 
	 public void enqueue(int val) { 
	 	 //Checks for empty queue for adding first element  
		 if(isEmpty()) { 
	 	 	 q_rear=0; 
	 	 	 q_front=0; 	 	 	  
	 	 } 
	 	 else { 
	 	 	 q_rear=(q_rear+1)%QUEUESIZE; 
	 	 } 
	 	 arr[q_rear]=val; 
	 } 
	 public int dequeue(int val) { 
	 	 int q_element; 
	 	 if(q_front==q_rear) // the only element in queue 
	 	 { 
	 	 	 q_element=arr[q_front]; 
	 	 	 q_rear=-1; //reseting rear for empty queue 
	 	 	 q_front=-1;//reseting front for empty queue 
	 	 } 
	 	 else { 
	 	 	 q_element=arr[q_front]; 
	 	 	 q_front=(q_front+1)%QUEUESIZE; 
	 	 } 
	 	 return q_element; 	  
	 } 
	 public boolean isEmpty() { 
	 	 	if(q_rear==-1) { 
	 	 	 	return true;  	 	 	
	 	 	 	}else {  	 	 	
	 	 	 		return false; 
	 	 	} 
	 	} 
	 
	 public boolean isFull() { 
	 	 	if((q_rear+1)%QUEUESIZE==q_front) { 
	 	 	 	return true;  	 	 	
	 	 	 	}else {  	 	 	 
	 	 	 		return false; 
	 	 	} 
	 	} 
	 public int size() {  
		 if(q_rear>q_front) { 
	 	 	 return q_rear-q_front+1; 
	 	 } 
	 	 else { 
	 	 	 return QUEUESIZE-q_rear-q_front+1; 
	 	 } 
	 } 
	 void displayAll() { 
	 	 	if(q_rear==-1) { 
	 	 	 	System.out.println("Queue is Empty!No elements to Display\n"); 
	 	 	 	return; 
	 	 	} 
	 	 	System.out.println("Elements in Queue are: "); 
	 	 	for(int i=q_front;i!=q_rear;i=(i+1)%QUEUESIZE) { 
	 	 	 	System.out.print(arr[i]+" "); 
	 	 	} 
	 	 	System.out.println(arr[q_rear]+" "); 
	 	 	System.out.println(""); 
	 	} 

//public class CircularQueueDemo { 
	public static void main(String[] args) { 
	 	// TODO Auto-generated method stub 
	 	Scanner sc=new Scanner(System.in);  
	 	MyCircularQueue st=new MyCircularQueue(5);  	 
	 	int val; 
	 	   int choice;  	 	  
	 	   do { 
	 	 	   System.out.println(" 1.Enqueue"); 
	 	 	   System.out.println(" 2.Dequeue"); 
	 	 	   System.out.println(" 3.Display");  	 	
	 	 	   System.out.println("Enter your choice: "); 
	 	 	   choice=sc.nextInt(); 
	 	 	   switch(choice)  
	 	 	   { 
	 	 	 	   case 1: 
	 	 	 	 	   if(st.isFull()) { 
	 	 	 	 	 	   System.out.println("\nQueue is Full "); 
	 	 	 	 	   }else { 

	 	 	 	 	 	   System.out.println("\nEnter Value to be Entered: "); 
	 	 	 	 	 	   val=sc.nextInt(); 
	 	 	 	 	 	   st.enqueue(val); 
	 	 	 	 	   } 
	 	 	 	 	   break;  	 	 	 	 
	 	 	 	 	   case 2: 
	 	 	 	 	   if(st.isEmpty()) { 
	 	 	 	 	 	   System.out.println("\nQueue is Empty !value cannot be removed "); 
	 	 	 	 	   }else { 
	 	 	 	 	   val=st.dequeue(3); 
	 	 	 	 	   System.out.println("\n Deleted element is:"+val); 
	 	 	 	 	   } 
	 	 	 	 	   break;  	 	 	 	
	 	 	 	 	   case 3: 
	 	 	 	 	   st.displayAll(); 
	 	 	 	 	   break; 
	 	 	 	 	   default: 
	 	 	 	 	System.out.println("\n Wrong choice!\n"); 
	 	 	 	 	 	   
	 	 	    	}//End of Switch 
	 	 	   }while(choice!=5); 
	} 

} 




package myPack;
import java.util.Scanner; 

public class MyStack {
	private int maxSize;  
	private int top;  	
	private int[] stackArray;  	
	public MyStack(int size) { 
 	 	maxSize=size; 
 	 	stackArray=new int[maxSize]; 
 	 	top=-1; 
 	} 
 	public void push(int value) {  	
 		if(isFull()) { 
 	 	 	System.out.println("stack is full! cannot push element"); 
 	 	}else { 
 	 	 	stackArray[++top]= value; 
 	 	} 
 	} 
 	public int pop() { 
 	 	if(isEmpty()) { 
 	 	 	System.out.println("Stack is Empty"); 
 	 	 	return -1; 
 	 	} 
 	 	else { 
 	 	 	return stackArray[top--]; 
 	 	} 
 	} 
 	public int peek() { 
 	 	if(isEmpty()) { 
 	 	 	System.out.println("Stack is Empty"); 
 	 	 	return -1; 
 	 	} 
 	 	else { 
 	 	 	return stackArray[top]; 
 	 	} 
 	} 
 	public boolean isFull() { 
 	 	return(top==maxSize-1); 
 	} 
 	public boolean isEmpty() { 
 	 	return(top==-1); 
 	} 
 	void displayAll() { 
 	 	if(isEmpty()) { 
 	 	 	System.out.println("Stack is Empty!No elements to Display\n"); 
 	 	} 
 	 	else{ 
 	 	 	System.out.println("Elements in stack are: ");  	 	 	
 	 	 	for(int i=top;i>=0;i--) { 
 	 	 	 	System.out.println(stackArray[i]); 
 	 	 	} 
 	 	 	System.out.println(""); 
 	 	} 
 	} 
 
//public class StackDemo {  	
public static void main(String[] args) {  	 	
	Scanner sc=new Scanner(System.in);  	
	MyStack st=new MyStack(5); 
 	 	   int val;  	 	
 	 	   int choice;  	 	  
 	 	   do { 
 	 	 	   System.out.println("\n 1.Push"); 
 	 	 	   System.out.println("\n 2.Pop"); 
 	 	 	   System.out.println("\n 3.Peek"); 
 	 	 	   System.out.println("\n 4.Display"); 
 	 	 	   System.out.println("\n 5.Exit"); 
 	 	 	   System.out.println("\nEnter your choice: "); 
 	 	 	   choice=sc.nextInt(); 
 	 	 	   switch(choice)  
 	 	 	   { 
 	 	 	 	   case 1: 
 	 	 	 	 	   System.out.println("\nEnter Value to be pushed: "); 
 	 	 	 	 	   val=sc.nextInt();  	 	 	 	
 	 	 	 	 	   st.push(val);  	 	 	 	 	
 	 	 	 	 	   break;  	 	 	 	 
 	 	 	 	 	   case 2: 
 	 	 	 	 	   val=st.pop(); 
 	 	 	 	 	   System.out.println("\n Popped element is:"+val); 
 	 	 	 	 	   break;  	 	 	 
 	 	 	 	 	   case 3: 
 	 	 	 	 	   System.out.println(st.peek());  
 	 	 	 	 	   break;  	 	 	 	
 	 	 	 	 	   case 4: 
 	 	 	 	 	   st.displayAll(); 
 	 	 	 	 	   break;  	 	 	 
 	 	 	 	 	   default: 
 	 	 	 	 	System.out.println("\n Wrong choice!\n"); 
 	 	 	}//End of Switch 
	 	 	   }while(choice!=5); 
	}} 



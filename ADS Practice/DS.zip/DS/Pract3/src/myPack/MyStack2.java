package myPack;
import java.util.Scanner; 

public class MyStack2 {
	private int maxSize; 
	private int top;  	
	private char[] stackArray;  
	public MyStack2(int size) { 
 	 	maxSize=size; 
 	 	stackArray=new char[maxSize]; 
 	 	top=-1; 
 	} 
 	public void push(char value) {  
 		if(isFull()) { 
 	 	 	System.out.println("stack is full! cannot push element"); 
 	 	}else { 
 	 	 	stackArray[++top]= value; 
 	 	} 
 	} 
 	public char pop() { 
 	 	if(isEmpty()) { 
 	 	 	System.out.println("Stack is Empty!cannot pop element"); 
 	 	 	return 'E'; //E means Empty 
 	 	} 
 	 	else { 
 	 	 	return stackArray[top--]; 
 	 	} 
 	} 
 	public char peek() { 
 	 	if(isEmpty()) { 
 	 	 	System.out.println("Stack is Empty"); 
 	 	 	return 'E'; 
 	 	} 
 	 	else { 
 	 	 	return stackArray[top]; 
 	 	} 
 	} 
 	public boolean isFull() { 
 	 	return(top==maxSize-1); 
 	} 
public boolean isEmpty() {  
	return(top==-1); 
} 
 	void displayAll() { 
 	 	if(isEmpty()) { 
 	 	 	System.out.println("Stack is Empty!No elements to Display\n"); 
 	 	} 
 	 	else{ 
 	 	 	System.out.println("Elements in stack are: ");  
 	 	 	for(int i=top;i>=0;i--) { 
 	 	 	 	System.out.println(stackArray[i]+"  "); 
 	 	 	} 
 	 	 	System.out.println(""); 
 	 	} 
 	} 

//public class ParanthesesBalancing { 
 	public static void main(String[] args) { 
 	 	// TODO Auto-generated method stub 
 	 	Scanner sc=new Scanner(System.in); 
 	 	MyStack2 st=new MyStack2(5); 
 	 	System.out.println("Please enter the Postfix expression"); 
 	 	String exp=sc.nextLine(); 
 	 	int isValid=1; 
 	 	char c; 
 	 	//Scan all characters one by one 
 	 	for(int i=0;i<exp.length();i++) { 
 	 	 	c=exp.charAt(i);  	 	 	
 	 	 	char stChar; 
 	 	 	if(c=='{' ||c=='[' || c=='(' ) { 
 	 	 	 	st.push(c); 
 	 	 	} 
 	 	 	else { 
 	 	 	 	if(st.isEmpty()) { 
 	 	 	 	 	isValid=0; 
 	 	 	 	 	break; 
 	 	 	 	} 	
 	 	 	 	else { 	
 	 	 	 	 	stChar=st.pop(); 
 	 	if((stChar!='(' && c==')')||(stChar!='{'&& c=='}')||(stChar!='['&&c==']')){
 	 					isValid = 0; 
 	 	 	 	 	 	break; 
 	 	 	 	 	} 
 	 	 	 	} 
	 	 	} 
	 	} 
	 	if(isValid==1 && st.isEmpty()) { 
	 	 	System.out.println("\n Parantheses are balanced"); 
	 	} 
 	 	else { 
 	 	 	System.out.println("\n Parantheses are NOT balanced"); 
 	 	} 
 	 	sc.close(); 
 	} 
 
} 
 


package myPack;

import myPack.MyStack3.InfixToPostfix;

public class InfixToPostFix extends InfixToPostfix {

}

package myPack;
import java.util.Scanner;
import java.lang.Math; 

public class MyStack1 {
	private int maxSize; 
	private int top;   
	private int[] stackArray;     
	public MyStack1(int size) {        
		maxSize = size;        
		stackArray = new int[maxSize];     
		top = -1; 
    } 
    public void push(int value) { 
        if (isFull()) { 
            System.out.println("Stack is full! Cannot push element!"); 
        } else { 
            stackArray[++top] = value; 
        } 
    } 
    public int pop() {        
    	if (isEmpty()) { 
            System.out.println("Stack is empty! Cannot pop element!");    
            return -1;         } 
    else { 
            return stackArray[top--]; 
        } 
    } 
    public int peek() {      
    	if (isEmpty()) { 
            System.out.println("Stack is empty!");      
            return -1;         } 
    	else { 
            return stackArray[top]; 
        } 
    } 
    public boolean isFull() { 
        return (top == maxSize - 1); 
    } 
    public boolean isEmpty() { 
    	return (top == -1); 
    } 
 
 
 
 
    public void displayAll() {    
    	if (top == -1) { 
            System.out.println("\nStack is empty! No elements to display\n");         } 
    	else { 
            System.out.println("Elements in the stack are:"); 
            for (int i = top; i >= 0; i--) { 
                System.out.print(stackArray[i] + " "); 
            } 
            System.out.println(""); 
        } 
    } 

//public class PostfixEval {   
	public static void main(String[] args) {   
		Scanner sc = new Scanner(System.in); 
        MyStack1 st = new MyStack1(20); // Increased stack size for complex expressions 
        System.out.println("Please enter postfix expression :"); 
        String exp = sc.nextLine();     
        for (int i = 0; i < exp.length(); i++) {        
        	char c = exp.charAt(i);         
        	if (Character.isDigit(c)) {       
        		st.push(c - '0');             } 
        	else {                     
        		int val1 = st.pop();     
        		int val2 = st.pop();        
        		int result = 0;          
        		switch (c) {                   
        		case '+':                        
        			result = val2 + val1; 
                        break;                 
                        case '-':         
                        	result = val2 - val1;           
                        	break;               
                        	case '*':         
                        		result = val2 * val1;       
                        		break;                    
                        		case '/':                    
                        			result = val2 / val1;                  
                        			break;                  
                        			case '^': 
                        result = (int) Math.pow(val2, val1);         
                        break;                
                        default: 
                        System.out.println("Invalid operator found!");                         continue; 
                } 
                st.push(result); 
        } 
    } 
    System.out.println("Answer = " + st.pop());      
    sc.close(); 
} 



}
